// Define o pacote (opcional, depende do teu projeto)
package part1

// Classe de dados para representar um nó de uma árvore binária genérica
// value: valor armazenado no nó
// left: referência para o filho à esquerda
// right: referência para o filho à direita
data class Node<E>(val value: E, var left: Node<E>? = null, var right: Node<E>? = null)


// ---------------------------------------------------------------------------
// Função que conta o número de nós com exatamente UM filho (esquerdo OU direito)
// ---------------------------------------------------------------------------
fun <E> countSingleChildNodes(root: Node<E>?): Int {
    // Caso base: se o nó atual for nulo, retorna 0
    if (root == null) return 0

    // Guarda os filhos esquerdo e direito do nó atual
    val left = root.left
    val right = root.right

    // Usa XOR lógico: verdadeiro se apenas UM dos filhos for não nulo
    val count = if ((left == null) xor (right == null)) 1 else 0

    // Soma este resultado com os das subárvores recursivamente
    return count + countSingleChildNodes(left) + countSingleChildNodes(right)
}


// ---------------------------------------------------------------------------
// Função que cria uma nova árvore espelhada (mirror): troca esquerda ↔ direita
// ---------------------------------------------------------------------------
fun <E> mirrorTree(root: Node<E>?): Node<E>? {
    // Caso base: se o nó atual for nulo, retorna nulo
    if (root == null) return null

    // Chamada recursiva: espelha a subárvore direita como nova esquerda
    val mirroredLeft = mirrorTree(root.right)

    // Espelha a subárvore esquerda como nova direita
    val mirroredRight = mirrorTree(root.left)

    // Retorna um novo nó com os filhos invertidos
    return Node(root.value, mirroredLeft, mirroredRight)
}


// ---------------------------------------------------------------------------
// Função que realiza a travessia zigzag de uma árvore binária por níveis
// Resultado: lista de listas, cada uma representando um nível da árvore
// Ordem: alterna entre esquerda→direita e direita→esquerda a cada nível
// ---------------------------------------------------------------------------
fun <E> zigzagTraversal(root: Node<E>?): List<List<E>> {
    // Lista onde serão guardados os níveis da árvore
    val result = mutableListOf<List<E>>()

    // Se a raiz for nula (árvore vazia), retorna lista vazia
    if (root == null) return result

    // Estrutura de fila para percorrer os nós por níveis (BFS)
    val queue = ArrayDeque<Node<E>>()

    // Começa com a raiz da árvore
    queue.add(root)

    // Variável que alterna a direção da travessia por nível
    var leftToRight = true

    // Enquanto houver nós na fila
    while (queue.isNotEmpty()) {
        // Número de nós no nível atual
        val levelSize = queue.size

        // Lista temporária que guarda os valores do nível atual
        val level = mutableListOf<E>()

        // Processa todos os nós do nível atual
        repeat(levelSize) {
            // Remove o nó da frente da fila
            val node = queue.removeFirst()

            // Adiciona o valor à lista do nível, na ordem correta
            if (leftToRight)
                level.add(node.value)         // Esquerda → Direita
            else
                level.add(0, node.value)      // Direita → Esquerda (inverte inserção)

            // Se existir filho à esquerda, adiciona à fila
            node.left?.let { queue.add(it) }

            // Se existir filho à direita, adiciona à fila
            node.right?.let { queue.add(it) }
        }

        // Adiciona a lista de valores deste nível ao resultado final
        result.add(level)

        // Inverte a direção para o próximo nível
        leftToRight = !leftToRight
    }

    // Retorna a lista completa com os níveis em ordem zigzag
    return result
}



















