package problem

import part1.Node
import part1.countSingleChildNodes
import part1.mirrorTree
import part1.zigzagTraversal
import part2.labelPropagation
import part2.loadGraphFromFile

fun main() {
        println("===== Parte 1: Árvores Binárias =====")

        // Criação de uma árvore binária de exemplo:
        //        1
        //       / \
        //      2   3
        //     /     \
        //    4       5
        val root = Node(1,
            left = Node(2, left = Node(4)),
            right = Node(3, right = Node(5))
        )

        // Exercício 1.1: Contar nós com apenas um filho
        val count = countSingleChildNodes(root)
        println("1.1) Nós com um só filho: $count")

        // Exercício 1.2: Criar árvore espelho
        val mirrored = mirrorTree(root)
        println("1.2) Árvore espelhada (zigzag):")
        println(zigzagTraversal(mirrored))

        // Exercício 1.3: Travessia em zigzag
        val zigzag = zigzagTraversal(root)
        println("1.3) Travessia em zigzag:")
        zigzag.forEachIndexed { level, values ->
            println("Nível $level: $values")
        }

        println("\n===== Parte 2: Grafos e Comunidades =====")

        // Caminho para um ficheiro .gr foi posto na raiz
        val path = "exemplo.gr"

        // Carrega o grafo do ficheiro
        val graph = loadGraphFromFile(path = path)
        println("Grafo carregado com ${graph.size} vértices.")

        // Executa o algoritmo de propagação de etiquetas
        val comunidades = labelPropagation(graph)

        // Imprime as comunidades
        println("Comunidades encontradas:")
        comunidades.forEach { (label, membros) ->
            println("Comunidade $label: $membros")
        }
}