package problem

import java.io.File

// Nó da árvore binária (exemplo para a Parte 1)
data class Node(val value: Int, val left: Node? = null, val right: Node? = null)

// Parte 1 - Funções dummy (implemente conforme necessário)
fun countSingleChildNodes(root: Node?): Int {
    if (root == null) return 0
    val countLeft = countSingleChildNodes(root.left)
    val countRight = countSingleChildNodes(root.right)
    val hasOneChild = (root.left == null) != (root.right == null) // XOR
    return (if (hasOneChild) 1 else 0) + countLeft + countRight
}

fun mirrorTree(root: Node?): Node? {
    if (root == null) return null
    return Node(root.value, mirrorTree(root.right), mirrorTree(root.left))
}

fun zigzagTraversal(root: Node?): List<List<Int>> {
    val result = mutableListOf<List<Int>>()
    if (root == null) return result
    val deque = ArrayDeque<Node>()
    deque.add(root)
    var leftToRight = true

    while (deque.isNotEmpty()) {
        val levelSize = deque.size
        val level = mutableListOf<Int>()
        for (i in 0 until levelSize) {
            val node = if (leftToRight) deque.removeFirst() else deque.removeLast()
            level.add(node.value)
            if (leftToRight) {
                node.left?.let { deque.addLast(it) }
                node.right?.let { deque.addLast(it) }
            } else {
                node.right?.let { deque.addFirst(it) }
                node.left?.let { deque.addFirst(it) }
            }
        }
        result.add(level)
        leftToRight = !leftToRight
    }
    return result
}

// Parte 2 - Carregar grafo a partir de ficheiro .gr simples
fun loadGraphFromFile(path: String): Map<Int, MutableSet<Int>> {
    val graph = mutableMapOf<Int, MutableSet<Int>>()
    File(path).forEachLine { line ->
        if (line.startsWith("e")) {
            val parts = line.split(" ")
            val u = parts[1].toInt()
            val v = parts[2].toInt()
            graph.getOrPut(u) { mutableSetOf() }.add(v)
            graph.getOrPut(v) { mutableSetOf() }.add(u)
        }
    }
    return graph
}

// Parte 2 - Algoritmo simples de propagação de etiquetas para comunidades
fun labelPropagation(graph: Map<Int, Set<Int>>): Map<Int, List<Int>> {
    val labels = mutableMapOf<Int, Int>()

    // Inicializa cada nó com um label único
    graph.keys.forEach { node -> labels[node] = node }

    var changed: Boolean
    do {
        changed = false
        for (node in graph.keys) {
            // Contar os labels dos vizinhos
            val neighborLabels = graph[node]?.mapNotNull { labels[it] } ?: emptyList()
            if (neighborLabels.isEmpty()) continue
            // Encontrar o label mais frequente entre os vizinhos
            val mostCommon = neighborLabels.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            if (mostCommon != null && labels[node] != mostCommon) {
                labels[node] = mostCommon
                changed = true
            }
        }
    } while (changed)

    // Agrupa os nós por label (comunidades)
    return labels.entries.groupBy({ it.value }, { it.key })
}

// Função principal
fun main() {
    println("===== Parte 1: Árvores Binárias =====")

    // Exemplo de árvore binária
    val root = Node(1,
        left = Node(2, left = Node(4)),
        right = Node(3, right = Node(5))
    )

    // Parte 1 - Exercícios
    val count = countSingleChildNodes(root)
    println("1.1) Nós com um só filho: $count")

    val mirrored = mirrorTree(root)
    println("1.2) Árvore espelhada (zigzag):")
    println(zigzagTraversal(mirrored))

    val zigzag = zigzagTraversal(root)
    println("1.3) Travessia em zigzag:")
    zigzag.forEachIndexed { level, values ->
        println("Nível $level: $values")
    }

    println("\n===== Parte 2: Grafos e Comunidades =====")

    val path = "exemplo.gr"
    val file = File(path)

    // Cria ficheiro .gr se não existir
    if (!file.exists()) {
        file.writeText("""
            c Grafo de exemplo gerado automaticamente
            p edge 5 4
            e 1 2
            e 1 3
            e 2 4
            e 4 5
        """.trimIndent())
        println("Ficheiro '$path' criado com conteúdo de exemplo.")
    }

    // Carrega grafo
    val graph = loadGraphFromFile(path)
    println("Grafo carregado com ${graph.size} vértices.")

    // Aplica propagação de etiquetas para comunidades
    val comunidades = labelPropagation(graph)

    // Mostra comunidades
    println("Comunidades encontradas:")
    comunidades.forEach { (label, membros) ->
        println("Comunidade $label: $membros")
    }

    // Guarda grafo final em formato.gr
    val grafoFile = File("grafo_final.gr")
    val arestas = mutableListOf<String>()
    graph.forEach { (nodo, vizinhos) ->
        vizinhos.forEach { vizinho ->
            if (nodo < vizinho) { // evitar duplicação
                arestas.add("e $nodo $vizinho")
            }
        }
    }
    val cabecalho = "p edge ${graph.size} ${arestas.size}"
    val conteudoGrafo = listOf("c Grafo gerado pelo programa", cabecalho) + arestas
    grafoFile.writeText(conteudoGrafo.joinToString("\n"))
    println("Grafo guardado em '${grafoFile.name}'.")

    // Guarda comunidades em ficheiro texto
    val comunidadesFile = File("comunidades.txt")
    val conteudoComunidades = comunidades.entries.joinToString("\n") { (label, membros) ->
        "Comunidade $label: ${membros.sorted()}"
    }
    comunidadesFile.writeText(conteudoComunidades)
    println("Comunidades guardadas em '${comunidadesFile.name}'.")
}
