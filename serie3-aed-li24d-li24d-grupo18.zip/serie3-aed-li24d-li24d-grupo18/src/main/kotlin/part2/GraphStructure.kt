package part2

import java.io.File

// Interface do grafo com vértices e arestas
interface Graph<I, D> {
    val size: Int
    fun addVertex(id: I, d: D): D?
    fun addEdge(id: I, idAdj: I): I?
    fun getVertex(id: I): Vertex<I, D>?
    fun getEdge(id: I, idAdj: I): Edge<I>?
    interface Vertex<I, D> {
        val id: I
        var data: D
        fun setData(newData: D): D
        fun getAdjacencies(): MutableSet<Edge<I>?>
    }
    interface Edge<I> {
        val id: I
        val adjacent: I
    }
}

// Implementação concreta da “interface” Graph para grafo não direcionado
class GraphStructure<I, D> : Graph<I, D>, Iterable<Graph.Vertex<I, D>> {

    private val vertices = mutableMapOf<I, VertexImpl>()

    // Implementação interna de um vértice
    inner class VertexImpl(
        override val id: I,
        override var data: D
    ) : Graph.Vertex<I, D> {

        private val adjacents = mutableSetOf<Graph.Edge<I>?>()

        override fun setData(newData: D): D {
            val old = data
            data = newData
            return old
        }

        override fun getAdjacencies(): MutableSet<Graph.Edge<I>?> = adjacents
    }

    // Implementação interna de uma aresta
    inner class EdgeImpl(
        override val id: I,
        override val adjacent: I
    ) : Graph.Edge<I>

    override val size: Int
        get() = vertices.size

    override fun addVertex(id: I, d: D): D? {
        if (vertices.containsKey(id)) return null
        vertices[id] = VertexImpl(id, d)
        return d
    }

    override fun addEdge(id: I, idAdj: I): I? {
        val v1 = vertices[id] ?: return null
        val v2 = vertices[idAdj] ?: return null

        val edge1 = EdgeImpl(id, idAdj)
        val edge2 = EdgeImpl(idAdj, id)

        v1.getAdjacencies().add(edge1)
        v2.getAdjacencies().add(edge2)

        return idAdj
    }

    override fun getVertex(id: I): Graph.Vertex<I, D>? = vertices[id]

    override fun getEdge(id: I, idAdj: I): Graph.Edge<I>? =
        vertices[id]?.getAdjacencies()?.firstOrNull { it?.adjacent == idAdj }

    override fun iterator(): Iterator<Graph.Vertex<I, D>> = vertices.values.iterator()
}

// Função para carregar um grafo de um ficheiro com formato simples: "1 → 2 3 4"
fun loadGraphFromFile(path: String): GraphStructure<Int, Unit> {
    val g = GraphStructure<Int, Unit>()

    File(path).forEachLine { raw ->
        val line = raw.trim()
        if (line.isBlank() || line.startsWith("#") || !line.contains("->")) return@forEachLine

        val (idStr, neighStr) = line.split("->", limit = 2)
        val vId = idStr.trim().toInt()
        g.addVertex(vId, Unit)

        neighStr.trim()
            .split(Regex("\\s+"))
            .filter(String::isNotBlank)
            .map(String::toInt)
            .forEach { nId ->
                g.addVertex(nId, Unit)
                g.addEdge(vId, nId)          // aresta dupla  (u,v) e (v,u)
            }
    }
    return g
}

// Algoritmo de Propagação de Etiquetas
fun labelPropagation(graph: GraphStructure<Int, Unit>): Map<Int, List<Int>> {
    val labels = mutableMapOf<Int, Int>()

    // Inicializa etiquetas com o próprio id
    graph.forEach { labels[it.id] = it.id }

    var changed: Boolean

    do {
        changed = false

        graph.forEach { v ->
            val neighborLabels = v.getAdjacencies()
                .mapNotNull { it?.adjacent?.let { adj -> labels[adj] } }

            if (neighborLabels.isNotEmpty()) {
                val mostCommon = neighborLabels
                    .groupingBy { it }
                    .eachCount()
                    .maxByOrNull { it.value }!!
                    .key

                if (labels[v.id] != mostCommon) {
                    labels[v.id] = mostCommon
                    changed = true
                }
            }
        }

    } while (changed)

    return labels.entries.groupBy({ it.value }, { it.key })
}
